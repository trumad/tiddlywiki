#!/bin/sh
open "$@"
