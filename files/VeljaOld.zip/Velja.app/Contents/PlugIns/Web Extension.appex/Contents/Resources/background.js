const browser = globalThis.browser ?? globalThis.chrome;
/// const isFirefox = globalThis.navigator.userAgent.includes('Firefox');
const isChrome = globalThis.navigator.userAgent.includes('Chrome');
const isSafari = !isChrome && globalThis.navigator.userAgent.includes('Safari');

async function openUrl(url, tabId) {
	if (isSafari) {
		await browser.runtime.sendNativeMessage('', {url});
	} else {
		browser.tabs.update(
			tabId,
			{
				url: `velja:open?fromBrowserExtension&url=${encodeURIComponent(url)}`,
			},
		);
	}
}

browser.contextMenus.create({
	id: 'openWithVelja',
	title: 'Open with Velja',
	contexts: [
		'link',
	],
});

browser.contextMenus.create({
	id: 'openPageWithVelja',
	title: 'Open Page with Velja',
	contexts: [
		'page',
	],
});

browser.contextMenus.onClicked.addListener((menuItem, tab) => {
	if (menuItem.menuItemId === 'openWithVelja') {
		openUrl(menuItem.linkUrl, tab.id);
	}

	if (menuItem.menuItemId === 'openPageWithVelja' && menuItem.pageUrl) {
		openUrl(menuItem.pageUrl, tab.id);
	}
});

browser.action.onClicked.addListener(tab => {
	openUrl(tab.url, tab.id);
});
